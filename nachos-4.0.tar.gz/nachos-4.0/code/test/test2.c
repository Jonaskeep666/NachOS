#include "syscall.h"

main()
        {
                int     n;
                for (n=20;n<=25;n++)
                        PrintInt(n);
        }
